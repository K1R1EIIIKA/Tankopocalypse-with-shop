import './Footer.css';

export default function Footer() {
	return (
		<footer className={'mt-4'}>
			<h3 className={'mb-0'}>Footer</h3>
		</footer>
	);
}